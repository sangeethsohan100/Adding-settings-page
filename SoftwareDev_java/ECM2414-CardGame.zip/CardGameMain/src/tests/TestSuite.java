import org.junit.runners.Suite;
import org.junit.runner.RunWith;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        PlayerTest.class,
        CardGameTest.class,
        CardDeckTest.class })

public class TestSuite {
}
