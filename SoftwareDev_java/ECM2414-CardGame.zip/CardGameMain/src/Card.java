public class Card {

    private int value; // value of the card

    // Constructor
    public Card(int cardValue) {
        this.value = cardValue;
    }

    // getter for the card value
    public int getCardValue() {
        return value;
    }
}
